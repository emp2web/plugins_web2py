fc.JS
====

Plugin jQuery que permite filtrar datos por columnas en una tabla HTML por medio de atributos HTML o JavaScript.

Las instrucciones pueden ser encontradas en: http://www.calbertts.com/codigo/proyecto/fcjs
